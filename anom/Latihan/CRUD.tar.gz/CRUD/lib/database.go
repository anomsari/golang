package lib

import (
	"database/sql"
	"fmt"
	"strings"

	_ "github.com/lib/pq"
)

type Table struct {
	Name  string
	Field []string
}

func Connect(username, password, database string) (*sql.DB, error) {
	comm := fmt.Sprintf("user=%s password=%s dbname=%s sslmode=disable",
		username, password, database)
	db, err := sql.Open("postgres", comm)
	return db, err
}

//drop database

func DropDB(db *sql.DB, name string) error {
	query := fmt.Sprintf("DROP DATABASE %v", name)
	_, err := db.Exec(query)
	return err
}

// create database
func CreateDB(db *sql.DB, name string) error {
	query := fmt.Sprintf("CREATE DATABASE %v", name)
	_, err := db.Exec(query)
	return err
}
func DropTable(db *sql.DB, table Table) error {
	query := fmt.Sprintf("DROP TABLE %v", table.Name)
	_, err := db.Exec(query)
	return err
}
func CreateTable(db *sql.DB, table Table) error {
	query := fmt.Sprintf("CREATE TABLE %v (%v)", table.Name, strings.Join(table.Field, ","))
	_, err := db.Exec(query)
	return err
}
