package test
import(
  "nyoba/Latihan/CRUD/model"
  "nyoba/Latihan/CRUD/lib"
  "testing"
)

var dataInsertMahasiswa = []model.Mahasiswa{
  model.Mahasiswa{NPM:"12345678", Nama: "Moon", Kelas: "1KB04"},
  model.Mahasiswa{NPM:"12222111", Nama: "Xen", Kelas: "1KB04"},
  model.Mahasiswa{NPM:"12345645", Nama: "Lo", Kelas: "1KB04"},
  model.Mahasiswa{NPM:"12345679", Nama: "jo", Kelas: "1KB04"},
}

func TestMahasiswa(t *testing.T){
  t.Run("Test Insert", func(t *testing.T){
    db, err := lib.Connect(username, pasword, namadatabase)

		defer db.Close()

		if err != err {
			t.Fatal(err)
		}
    for _, dataInsert := range dataInsertMahasiswa{
      err := dataInsert.Insert(db)
      if err != nil {
        t.Fatal(err)
      }
    }

  })
  }
