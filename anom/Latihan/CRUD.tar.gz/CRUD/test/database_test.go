package test

import (
	"nyoba/Latihan/CRUD/lib"
	"nyoba/Latihan/CRUD/model"
	"testing"
)

var username, pasword, namadatabase, databaseDefault string

func init() {
	username = "postgres"
	pasword = "postgres"
	namadatabase = "latihancrud"
	databaseDefault = "postgres"
}

func TestDatabase(t *testing.T) {
	t.Run("Testing koneksi postgres", func(t *testing.T) {
		db, err := lib.Connect(username, pasword, databaseDefault)

		defer db.Close()

		if err != nil {
			t.Fatal(err)
		}

	})
	t.Run("Testing Drop postgres", func(t *testing.T) {
		db, err := lib.Connect(username, pasword, databaseDefault)

		defer db.Close()

		if err != err {
			t.Fatal(err)
		}
		err = lib.DropDB(db, namadatabase)
		if err != nil {
			t.Fatal(err)
		}
	})
	t.Run("Testing Create postgres", func(t *testing.T) {
		db, err := lib.Connect(username, pasword, databaseDefault)

		defer db.Close()

		if err != err {
			t.Fatal(err)
		}
		err = lib.CreateDB(db, namadatabase)
		if err != nil {
			t.Fatal(err)
		}
	})

	// t.Run("Testing Drop table Mahasiswa", func(t *testing.T) {
	// 	db, err := lib.Connect(username, pasword, namadatabase)
	//
	// 	defer db.Close()
	//
	// 	if err != err {
	// 		t.Fatal(err)
	// 	}
	// 	err = lib.DropTable(db, model.TabelMahasiswa)
	// 	if err != nil {
	// 		t.Fatal(err)
	// 	}
	// })

	t.Run("Testing Create table Mahasiswa", func(t *testing.T) {
		db, err := lib.Connect(username, pasword, namadatabase)

		defer db.Close()

		if err != err {
			t.Fatal(err)
		}
		err = lib.CreateTable(db, model.TabelMahasiswa)
		if err != nil {
			t.Fatal(err)
		}
	})

}
