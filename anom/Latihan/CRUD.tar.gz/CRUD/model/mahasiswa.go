package model

import (
	"database/sql"
	"nyoba/Latihan/CRUD/lib"
)

type Mahasiswa struct {
	NPM   string
	Nama  string
	Kelas string
}

var TabelMahasiswa = lib.Table{
	Name: "Mahasiswa",
	Field: []string{
		"npm VARCHAR(10)PRIMARY KEY NOT NULL",
		"nama VARCHAR(30) NOT NULL",
		"kelas VARCHAR(5) NOT NULL",
	},
}

func (m *Mahasiswa) Insert(db *sql.DB) error {
	query := "INSERT INTO mahasiswa VALUES ($1, $2, $3)"
	_, err := db.Exec(query, m.NPM, m.Nama, m.Kelas)
	return err

}

func (m *Mahasiswa) Delete(db *sql.DB) error {
	query := "Delete FROM mahasiswa WHERE npm = $1"
	_, err := db.Exec(query, m.Nama)
	return err

}

func (m *Mahasiswa) SelectallMahasisa(db *sql.DB) error {
	query := "Select * FROMmahasiswa WHERE npm = $1"
	err := db.QueryRow(query, m.NPM).Scan(&m.NPM, &m.Nama, &m.Kelas)
	return err

}
